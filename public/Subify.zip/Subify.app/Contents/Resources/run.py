#!/usr/bin/env python3
"""
Spotify Lyrics Overlay — macOS Menu Bar App
Displays synced lyrics as floating subtitles at the bottom of the screen.

Usage:
    python3 run.py
"""

import sys
import os

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))

from app import create_app

if __name__ == '__main__':
    app = create_app()
    app.run()
