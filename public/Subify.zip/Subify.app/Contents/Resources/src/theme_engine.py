"""
ThemeEngine — 5 Glassmorphism Presets and Custom Color Styling for Subify v2.0
"""

import objc
import AppKit
from AppKit import (
    NSColor, NSVisualEffectMaterialHUDWindow,
    NSVisualEffectMaterialToolTip, NSVisualEffectMaterialPopover,
    NSVisualEffectMaterialMenu, NSVisualEffectMaterialSelection
)
from Quartz import CGColorCreateGenericRGB


class Theme:
    def __init__(self, name, material, border_rgb, shadow_rgb, text_color, next_text_color, accent_color):
        self.name = name
        self.material = material
        self.border_rgb = border_rgb
        self.shadow_rgb = shadow_rgb
        self.text_color = text_color
        self.next_text_color = next_text_color
        self.accent_color = accent_color

    def create_border_color(self):
        return CGColorCreateGenericRGB(*self.border_rgb)

    def create_shadow_color(self):
        return CGColorCreateGenericRGB(*self.shadow_rgb)


THEMES = {
    'dark': Theme(
        name='Dark Glass',
        material=NSVisualEffectMaterialHUDWindow,
        border_rgb=(1.0, 1.0, 1.0, 0.22),
        shadow_rgb=(0.0, 0.0, 0.0, 0.5),
        text_color=NSColor.colorWithWhite_alpha_(1.0, 1.0),
        next_text_color=NSColor.colorWithWhite_alpha_(1.0, 0.5),
        accent_color=NSColor.colorWithRed_green_blue_alpha_(0.3, 0.8, 1.0, 1.0)
    ),
    'light': Theme(
        name='Light Frost',
        material=NSVisualEffectMaterialToolTip,
        border_rgb=(0.0, 0.0, 0.0, 0.15),
        shadow_rgb=(0.0, 0.0, 0.0, 0.25),
        text_color=NSColor.colorWithWhite_alpha_(0.1, 1.0),
        next_text_color=NSColor.colorWithWhite_alpha_(0.2, 0.6),
        accent_color=NSColor.colorWithRed_green_blue_alpha_(0.0, 0.47, 1.0, 1.0)
    ),
    'cyberpunk': Theme(
        name='Cyberpunk Neon',
        material=NSVisualEffectMaterialHUDWindow,
        border_rgb=(0.0, 0.9, 1.0, 0.6),
        shadow_rgb=(0.8, 0.0, 1.0, 0.4),
        text_color=NSColor.colorWithRed_green_blue_alpha_(0.3, 0.95, 1.0, 1.0),
        next_text_color=NSColor.colorWithRed_green_blue_alpha_(1.0, 0.4, 0.9, 0.7),
        accent_color=NSColor.colorWithRed_green_blue_alpha_(1.0, 0.2, 0.8, 1.0)
    ),
    'gold': Theme(
        name='Golden Hour',
        material=NSVisualEffectMaterialPopover,
        border_rgb=(1.0, 0.8, 0.3, 0.45),
        shadow_rgb=(0.3, 0.2, 0.0, 0.5),
        text_color=NSColor.colorWithRed_green_blue_alpha_(1.0, 0.92, 0.7, 1.0),
        next_text_color=NSColor.colorWithRed_green_blue_alpha_(1.0, 0.75, 0.4, 0.6),
        accent_color=NSColor.colorWithRed_green_blue_alpha_(1.0, 0.8, 0.2, 1.0)
    ),
    'carbon': Theme(
        name='Minimal Carbon',
        material=NSVisualEffectMaterialHUDWindow,
        border_rgb=(0.3, 0.3, 0.35, 0.3),
        shadow_rgb=(0.0, 0.0, 0.0, 0.7),
        text_color=NSColor.colorWithWhite_alpha_(0.95, 1.0),
        next_text_color=NSColor.colorWithWhite_alpha_(0.5, 0.5),
        accent_color=NSColor.colorWithWhite_alpha_(1.0, 0.9)
    )
}


def get_theme(name: str) -> Theme:
    return THEMES.get(name.lower(), THEMES['dark'])
